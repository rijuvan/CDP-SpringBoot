package com.soft.infg;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.soft.infg.model.Message;
import com.soft.infg.model.MessageRepository;

import springfox.documentation.swagger2.annotations.EnableSwagger2;

@SpringBootApplication
@EnableSwagger2
public class DemoAppTrApplication implements CommandLineRunner{

	@Autowired
	MessageRepository repo;
	
	public static void main(String[] args) {
		SpringApplication.run(DemoAppTrApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		
		repo.save(new Message("Message1"));
		
	}

}

