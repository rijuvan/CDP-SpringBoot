package com.soft.infg.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Message {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int messageId;
	private String messageConent;
	public Message(String messageConent) {
		
		this.messageConent = messageConent;
	}
	public Message() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getMessageId() {
		return messageId;
	}
	public void setMessageId(int messageId) {
		this.messageId = messageId;
	}
	public String getMessageConent() {
		return messageConent;
	}
	public void setMessageConent(String messageConent) {
		this.messageConent = messageConent;
	}
	@Override
	public String toString() {
		return "Message [messageId=" + messageId + ", messageConent=" + messageConent + "]";
	}
	
	

}
