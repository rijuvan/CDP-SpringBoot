package com.soft.infg.repositry;

import org.springframework.data.jpa.repository.JpaRepository;

import com.soft.infg.model.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {

}
