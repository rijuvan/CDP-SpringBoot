package com.soft.infg;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import com.soft.infg.model.MessageRepository;

import springfox.documentation.swagger2.annotations.EnableSwagger2;

import com.soft.infg.model.Message;

@SpringBootApplication
@EnableSwagger2
public class TrainingRestApplication implements CommandLineRunner {

	@Autowired
	MessageRepository repos;
	
	public static void main(String[] args) {
		SpringApplication.run(TrainingRestApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		
		repos.save(new Message("Welcome -1"));
		repos.save(new Message("Welcome -2"));
		repos.save(new Message("Welcome -3"));
	}

}

