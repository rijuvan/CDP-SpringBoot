package com.soft.infg.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Message {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int messageId;
	private String messageContent;

	public Message(String messageContent) {

		this.messageContent = messageContent;
	}

	@Override
	public String toString() {
		return "Message [messageId=" + messageId + ", messageContent=" + messageContent + "]";
	}

	public int getMessageId() {
		return messageId;
	}

	public void setMessageId(int messageId) {
		this.messageId = messageId;
	}

	public String getMessageContent() {
		return messageContent;
	}

	public void setMessageContent(String messageContent) {
		this.messageContent = messageContent;
	}

	public Message() {
		super();
		// TODO Auto-generated constructor stub
	}

}
