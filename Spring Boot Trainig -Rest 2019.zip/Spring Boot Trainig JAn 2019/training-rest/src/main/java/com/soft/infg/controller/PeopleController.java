package com.soft.infg.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class PeopleController {
	
	@RequestMapping("/people")
	public String askPeople()
	{
		
		return "This is my people controller !!";
	}

}
