package com.soft.infg.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.util.*;

import com.soft.infg.model.Message;
import com.soft.infg.model.MessageRepository;

@RestController
public class TrainingController {

	@Autowired
	MessageRepository repos;

	@RequestMapping(path="/welcome")
	public String sayHello() {
		return "Welcome to Infogainm India  - Noida Sector 60 + Mumbai!!";
	}

	
	/*public Iterable<Message> showAllemployee()
	{
		return repos.findAll();
	}*/
}
