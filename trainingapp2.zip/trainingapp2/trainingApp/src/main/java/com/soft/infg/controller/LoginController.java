package com.soft.infg.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.soft.infg.service.LoginService;

@SessionAttributes("name")
@Controller
public class LoginController {

	@Autowired
	LoginService loginservice;

	/*@RequestMapping("/")
	// @ResponseBody
	public String login(ModelMap model) {
		System.out.println(model.get("errorMessage"));
		return "login";
	}*/

	@RequestMapping(value = "/loginValidate", method = RequestMethod.POST)
	public String validateUser(@RequestParam String user, @RequestParam String passwd, ModelMap model)

	{
		if (!loginservice.validateUser(user, passwd)) {
			{
				model.addAttribute("errorMessage", "Invalid Credentials!!");
				System.out.println(model.get("errorMessage"));
				return "login";
			}
		} else {
			model.put("name", user);
			return "welcome";
		}
	}
}
