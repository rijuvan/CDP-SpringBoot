package com.soft.infg.service;

import java.util.Hashtable;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.soft.infg.model.UserDetail;
import com.soft.infg.repositry.UserDetailRepositry;

@Component
public class LoginService {

	@Autowired
	private UserDetailRepositry userrepo;
	/*
	 * static Hashtable<String, String> logindata = new Hashtable<>();
	 * 
	 * static { logindata.put("infogain", "infogain"); logindata.put("infogainpune",
	 * "infogainpune"); }
	 */

	public boolean validateUser(String username, String passwd) {
		UserDetail userdetail = userrepo.findByUsername(username);
		System.out.println(userdetail);
			if (userdetail==null)
				return false;
			else {

				if ((userdetail.getUsername().equals(username)) && (userdetail.getPassword().equals(passwd)))
					return true;
				else
					return false;
			}
	}
}
