package com.soft.infg.repositry;


import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;


import com.soft.infg.model.UserDetail;

//@RepositoryRestResource(collectionResourceRel = "users", path = "users")
public interface UserDetailRepositry extends PagingAndSortingRepository<UserDetail,Integer> {
	
	public UserDetail findByUsername(@Param("username") String username );

}
