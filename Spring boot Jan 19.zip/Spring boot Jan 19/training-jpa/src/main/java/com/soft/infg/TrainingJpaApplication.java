package com.soft.infg;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.soft.infg.model.UserDetail;
import com.soft.infg.repositry.UserDetailRepositry;

@SpringBootApplication
public class TrainingJpaApplication implements CommandLineRunner {
	@Autowired
	private UserDetailRepositry userrepo;

	public static void main(String[] args) {
		SpringApplication.run(TrainingJpaApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub

		UserDetail user1 = new UserDetail("Amit", "Amit");

		UserDetail user2 = new UserDetail("Sumit", "Sumit");
		UserDetail user3 = new UserDetail("Dev", "Dev");
		UserDetail user4 = new UserDetail("Infogain", "Infogain");

		userrepo.save(user1);
		userrepo.save(user2);
		userrepo.save(user3);
		userrepo.save(user4);

		userrepo.findAll().forEach(System.out::println);

	}
}
