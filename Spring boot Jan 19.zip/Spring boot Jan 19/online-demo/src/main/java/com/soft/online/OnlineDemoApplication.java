package com.soft.online;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlineDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlineDemoApplication.class, args);
	}

}

