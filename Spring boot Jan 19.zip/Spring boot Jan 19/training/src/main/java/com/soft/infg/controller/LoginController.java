package com.soft.infg.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.soft.infg.service.LoginService;

@Controller
public class LoginController {

	@Autowired
	LoginService loginservice;

	@RequestMapping("/")
	// @ResponseBody
	public String login() {
		return "login";
	}

	@RequestMapping("/loginValidate")
	public String validateUser(@RequestParam String user, @RequestParam String passwd, ModelMap model)

	{
		if (!loginservice.validateUser(user, passwd)) {
			return "redirect:/";

		} else {
			model.put("name", user);
			return "welcome";
		}
	}
}
