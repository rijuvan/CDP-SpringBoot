package com.soft.infg.service;

import java.util.Hashtable;

import org.springframework.stereotype.Component;

@Component
public class LoginService {

	static Hashtable<String, String> logindata = new Hashtable<>();

	static {
		logindata.put("infogain", "infogain");
		logindata.put("infogainpune", "infogainpune");
	}

	public boolean validateUser(String username, String passwd) {
		if (logindata.get(username).equals(passwd))
			return true;
		else
			return false;
	}

}
