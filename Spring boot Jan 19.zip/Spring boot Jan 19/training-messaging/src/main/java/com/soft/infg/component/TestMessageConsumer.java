package com.soft.infg.component;

import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

@Component
public class TestMessageConsumer {
	
	@RabbitListener(queues = "newDynamicQueue")
	public void processMessage(String content) {
	System.out.println("The message is " + content);
	}

}
