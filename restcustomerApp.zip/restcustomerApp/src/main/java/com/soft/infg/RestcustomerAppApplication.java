package com.soft.infg;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.soft.infg.model.Customer;
import com.soft.infg.repositry.CustomerRespository;

import springfox.documentation.swagger2.annotations.EnableSwagger2;

@SpringBootApplication
@EnableSwagger2
public class RestcustomerAppApplication implements CommandLineRunner {

	@Autowired
	CustomerRespository customerRepository;

	public static void main(String[] args) {
		SpringApplication.run(RestcustomerAppApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		customerRepository.save(new Customer("Amit", "Amit@boot.com"));
		customerRepository.save(new Customer("Jack", "jack@boot.com"));
		customerRepository.save(new Customer("Sumit", "sumit@boot.com"));
		customerRepository.save(new Customer("NewUser", "newUser@boot.com"));
		customerRepository.save(new Customer("Mohit", "mohit@boot.com"));
		customerRepository.save(new Customer("Tom", "tom@boot.com"));
		customerRepository.save(new Customer("Sean", "sean@boot.com"));
	}

}
