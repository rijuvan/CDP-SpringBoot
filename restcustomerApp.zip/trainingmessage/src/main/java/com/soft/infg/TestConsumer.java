package com.soft.infg;

import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

@Component
public class TestConsumer {
	
	@RabbitListener(queues = "newDynamicQueue")
	public void processMessage(String content) {
	System.out.println(content);
	}

}
